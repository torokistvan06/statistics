function b = isInCircle(xc, yc, r, x, y)
b = (x - xc) ^ 2  + (y - yc) ^ 2 <= r^2;
end

